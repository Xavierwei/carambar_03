<?php
	header("Location: api/admin/index",true,303);
	die();
?>