### Cache Configuration

```
        "cache" => array(
            "class" => "CMemCache",
            "servers" => array(
                array(
                    "host" => "127.0.0.1",
                    "port" => "11211",
                    "weight" => 1
                ),
            ),
        ),
```
