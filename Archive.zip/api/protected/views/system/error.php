
Error <?php echo $data['code']; ?>
<?php echo nl2br(CHtml::encode($data['message'])); ?>