<body class="login-body">
  <div class="page login-page">
	  <!-- header -->
	  <div class="login-header">
		  <a href="<?php echo Yii::app()->request->baseUrl; ?>/../index" class="logo"></a>
	  </div>
	  <!--  -->
	  <a class="login-btn" href="<?php echo Yii::app()->request->baseUrl; ?>/user/samllogin">
		  Login
	  </a>

  </div>
</body>