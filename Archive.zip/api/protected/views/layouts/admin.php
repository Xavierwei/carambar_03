<!doctype html>
<html lang="en" ng-app="SGWallAdmin">
<head>
	<meta charset="utf-8">
	<title>L'ESPRIT D'EQUIPE SOCIETE GENERALE</title>
	<meta http-equiv="X-UA-Compatible" content="IE=11; IE=10; IE=9; IE=8" />
	<link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/admin_asset/css/bootstrap.css"/>
	<link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/admin_asset/css/admin.css?<?php echo time();?>"/>
</head>

<?php echo $content; ?>

</html>
