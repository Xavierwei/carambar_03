<?php if($url): ?>
	<script>
		window.top.closeAvatarPop("<?php echo $url?>");
	</script>
<?php endif;?>