<?php
/**
 * Exception indicating illegal innput from user.
 * 
 * @author Thomas Graff <thomas.graff@uninett.no>
 * @package simpleSAMLphp_base
 * @version $Id$
 *
 */
class SimpleSAML_Error_BadUserInnput extends SimpleSAML_Error_User{
	
}

?>