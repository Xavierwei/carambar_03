#### Test for performance

http://pylot.org/gettingstarted.html


#### 开始测试

./run.sh
