<?php
define( "TWITTER_AKEY" , 'qsKqTSoIRbqvkWCrNAbjKw' );
define( "TWITTER_SKEY" , 'q9KfWKWq8KLPUBFytQBB5lkjEZy7pxTE916n3iVkXc');
define( "TWITTER_CALLBACK_URL" , 'http://lily.local/carambar/api/twitter/callback' );