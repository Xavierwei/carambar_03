<?php
define( "FB_APPID" , '248138168701760' );
define( "FB_SKEY" , '5c444919a239bd68741044848442d3b0');
define( "FB_CALLBACK_URL" , 'http://lily.local:8888/carambar_03/api/instagram/callback' );