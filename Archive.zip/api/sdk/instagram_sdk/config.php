<?php
define( "INSTAGRAM_AKEY" , '28fb0c1bb927466887453e56d7e3a978' );
define( "INSTAGRAM_SKEY" , '7bf1f584018f462a916d486978513137');
define( "INSTAGRAM_CALLBACK_URL" , 'http://lily.local/carambar/api/instagram/callback' );