WallAdminController
    .controller('VideoCtrList', function($scope, $http, $modal, $log, $routeParams,VideoService, NodeService,  ASSET_FOLDER) {
		VideoService.list({},function(data){
			$scope.videos = data.data;
		});

        // Delete node
        $scope.delete = function(video) {
            var modalInstance = $modal.open({
                templateUrl: ASSET_FOLDER+'tmp/dialog/delete.html',
                controller: ConfirmModalCtrl
            });

            modalInstance.result.then(function () {
                $scope.videos.splice($scope.videos.indexOf(video), 1);
                VideoService.update({vid:video.vid, status:0});
            }, function () {
            });

        }

    })

    .controller('VideoCtrCreate', function($scope, $http, $modal, $log, $routeParams,VideoService,  ASSET_FOLDER) {
        $scope.save = function(video) {
            VideoService.post(video, function(data){
            console.log(data);
            });
        }
    })

    .controller('VideoCtrEdit', function($scope, $http, $modal, $log, $routeParams,VideoService, $location,  ASSET_FOLDER) {
		VideoService.getById($routeParams.vid, function(data){
			$scope.video = data.data;
		});

		$scope.save = function(video) {
            video.del = 0;
			VideoService.update(video, function(data){
                $location.path("video");
			});
		}
	})


	.controller('VideoCtrPhase', function($scope, $http, $modal, $log, $routeParams,VideoService, ASSET_FOLDER) {
        $scope.phase = $routeParams.phaseid;

		VideoService.list({phase:$routeParams.phaseid},function(data){
			$scope.videos = data.data;
		});

        VideoService.list({},function(data){
            $scope.allvideos = data.data;
        });

		$scope.save = function(video) {
            if(!video) {
                return;
            }
            video.phase = $routeParams.phaseid;
            video.del = 0;
			VideoService.update(video, function(data){
                console.log($scope.videos.indexOf(video));
                console.log($scope.videos);
                console.log(video);
                $scope.videos.push(video);
			});
		}

        $scope.remove = function(video) {
            video.phase = $routeParams.phaseid;
            video.del = 1;
            VideoService.update(video, function(data){
                $scope.videos.splice($scope.videos.indexOf(video), 1);
            });
        }
	})



